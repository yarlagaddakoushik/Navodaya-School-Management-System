<?php 
 echo "Mark attendance under construction";
 ?>