<?php
   echo"View Attendance under construction";
?>