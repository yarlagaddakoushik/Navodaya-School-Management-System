<?php
   echo"chat under construction";
?>